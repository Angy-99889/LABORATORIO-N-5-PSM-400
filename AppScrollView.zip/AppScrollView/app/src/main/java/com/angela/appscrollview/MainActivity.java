package com.angela.appscrollview;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    /*
    public void Seleccion(View view){
        switch (view.getId()){
            case R.id.ib_azul;
                Toast.makeText(this, "Esto es un Color Azul", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_rojo;
                Toast.makeText(this, "Esto es un Color Rojo", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_verde;
                Toast.makeText(this, "Esto es un Color Verde", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_send;
                Toast.makeText(this, "Esto para enviar Inmormacion", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_enviar;
                Toast.makeText(this, "Esto es para Enviar", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_frutas;
                Toast.makeText(this, "Esto son las Frutas", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_frutilla;
                Toast.makeText(this, "Esto es  una Frutilla", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_manzana;
                Toast.makeText(this, "Esto es una Manzna", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_platano;
                Toast.makeText(this, "Esto es un Platano", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_flores;
                Toast.makeText(this, "Esto es unas Flores", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ib_paisaje;
                Toast.makeText(this, "Esto es un Paisaje", Toast.LENGTH_SHORT).show();
                break;
        }
    }*/
}