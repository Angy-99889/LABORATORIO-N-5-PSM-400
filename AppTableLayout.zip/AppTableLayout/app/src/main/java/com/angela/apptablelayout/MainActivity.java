package com.angela.apptablelayout;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvMostrar;
    String operador = "";
    boolean nuevoNumero = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvMostrar = findViewById(R.id.tv_mostrar);

        int[] numeros = {R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3, R.id.btn_4,
                R.id.btn_5, R.id.btn_6, R.id.btn_7, R.id.btn_8, R.id.btn_9};

        View.OnClickListener listenerNumeros = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                if (nuevoNumero) {
                    tvMostrar.setText(b.getText().toString());
                    nuevoNumero = false;
                } else {
                    tvMostrar.append(b.getText().toString());
                }
            }
        };

        for (int id : numeros) {
            findViewById(id).setOnClickListener(listenerNumeros);
        }

        findViewById(R.id.btn_sumar).setOnClickListener(v -> setOperador("+"));
        findViewById(R.id.btn_restar).setOnClickListener(v -> setOperador("-"));
        findViewById(R.id.btn_multi).setOnClickListener(v -> setOperador("*"));
        findViewById(R.id.btn_div).setOnClickListener(v -> setOperador("/"));


        findViewById(R.id.btn_resultado).setOnClickListener(v -> calcular());
        
        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            tvMostrar.setText("0");
            operador = "";
            nuevoNumero = false;
        });
    }

    private void setOperador(String op) {
        if (!tvMostrar.getText().toString().contains("+") &&
                !tvMostrar.getText().toString().contains("-") &&
                !tvMostrar.getText().toString().contains("*") &&
                !tvMostrar.getText().toString().contains("/")) {

            operador = op;
            tvMostrar.append(op);
            nuevoNumero = false;
        }
    }

    private void calcular() {
        String texto = tvMostrar.getText().toString();

        if (operador.isEmpty() || !texto.contains(operador)) {
            return;
        }

        String[] partes = texto.split("\\" + operador);
        if (partes.length < 2) return;

        double num1, num2, resultado = 0;

        try {
            num1 = Double.parseDouble(partes[0]);
            num2 = Double.parseDouble(partes[1]);
        } catch (Exception e) {
            tvMostrar.setText("Error");
            return;
        }

        switch (operador) {
            case "+": resultado = num1 + num2; break;
            case "-": resultado = num1 - num2; break;
            case "*": resultado = num1 * num2; break;
            case "/":
                if (num2 != 0) {
                    resultado = num1 / num2;
                } else {
                    tvMostrar.setText("Error");
                    return;
                }
                break;
        }

        tvMostrar.setText(String.valueOf(resultado));
        operador = "";
        nuevoNumero = true;
    }
}