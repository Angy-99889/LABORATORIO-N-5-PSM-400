package com.angela.applineallayout2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etn, etp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        etn = findViewById(R.id.txt_nombre);
        etp = findViewById(R.id.txt_Password);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void Siguiente(View view) {
        String nombre = etn.getText().toString().trim();
        String pass = etp.getText().toString().trim();

        if (nombre.isEmpty()) {
            Toast.makeText(this, "Debe ingresar un Nombre", Toast.LENGTH_SHORT).show();
            return;
        }

        if (pass.isEmpty()) {
            Toast.makeText(this, "Debe ingresar una Contraseña", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Registro en proceso........", Toast.LENGTH_SHORT).show();
        Intent next = new Intent(this, LinealLayout3.class);
        next.putExtra("dato_nombre", nombre);
        next.putExtra("dato_pass", pass);
        startActivity(next);
    }
}